package com.example.aviones;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    public void onLogin(View view){
        EditText Nome = findViewById(R.id.nom);
        EditText Contraseña = findViewById(R.id.contr);
        String user1 = "root";
        String pswd1 = "root";
        String user = Nome.getText().toString();
        String pswd = Contraseña.getText().toString();

        Intent registro = getIntent();
        //user = registro.getExtras().getString(user);
        //pswd = registro.getExtras().getString(pswd);


        if((user.equals(user1)) && (pswd.equals(pswd1))){
            Intent intent = new Intent(this, interfazinternaclass.class);
            startActivity(intent);
        }
        else Toast.makeText(MainActivity.this, "The login data is incorrect", Toast.LENGTH_SHORT).show();

    }
    public void onRegister(View view){
        /*EditText Nome = (EditText) findViewById(R.id.nom);
        EditText Contraseña = (EditText) findViewById(R.id.contr);
        String user = Nome.getText().toString();
        String pswd = Contraseña.getText().toString();

        Intent registro = new Intent(this, MainActivity.class);
        registro.putExtra(user, pswd);
        startActivity(registro);
        */
        Toast.makeText(MainActivity.this, "Not able to do this action", Toast.LENGTH_SHORT).show();
    }

}

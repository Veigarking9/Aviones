package com.example.aviones;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class listaclass extends AppCompatActivity {



    int[] images = {R.drawable.iconoavion};

    ListView lView;
    ListAdapter lAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Intent hist = getIntent();
        String Origen = "";
        String Destiny = "";
        String Dateg = "";
        String Datec = "";
        if(hist.hasExtra("Origen")){
            Origen = hist.getStringExtra("Origen");
        }
        if(hist.hasExtra("Destiny")){
            Destiny = hist.getStringExtra("Destiny");
        }
        if(hist.hasExtra("Salida")){
            Dateg = hist.getStringExtra("Salida");
        }
        if(hist.hasExtra("Vuelta")){
            Datec = hist.getStringExtra("Vuelta");
        }

        String[] version = {Origen+"-"+Destiny};
        String[] Salida = {Dateg};
        String[] Vuelta = {Datec};


        super.onCreate(savedInstanceState);
        setContentView(R.layout.listavuelos);
        lView = (ListView) findViewById(R.id.androidList);
        lAdapter = new ListAdapter(listaclass.this, version, Salida, Vuelta,  images);
        lView.setAdapter(lAdapter);
        lView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(listaclass.this, version[i]+" "+Salida[i]+" "+Vuelta[i], Toast.LENGTH_SHORT).show();
            }
        });
    }
}
package com.example.aviones;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ListAdapter extends BaseAdapter {
    Context context;
    private final String[] values;
    private final String[] Salida;
    private final String[] Vuelta;
    private final int[] images;

    public ListAdapter(Context context, String[] values, String[] Salida, String[] Vuelta, int[] images) {
        this.context = context;
        this.values = values;
        this.Salida = Salida;
        this.Vuelta = Vuelta;
        this.images = images;

    }

    @Override
    public int getCount() {
        return values.length;
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        final View result;
        if (convertView == null) {
            viewHolder = new ViewHolder();
            LayoutInflater inflater =
                    LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.filalista, parent, false);
            viewHolder.txtName = (TextView)
                    convertView.findViewById(R.id.aNametxt);
            viewHolder.txtVersion = (TextView)
                    convertView.findViewById(R.id.aVersiontxt);
            viewHolder.icon = (ImageView)
                    convertView.findViewById(R.id.appIconIV);
            result = convertView;
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
            result = convertView;
        }
        viewHolder.txtName.setText(values[position]);
        viewHolder.txtVersion.setText(Salida[position]+" <-||-> "+Vuelta[position]);
        viewHolder.icon.setImageResource(images[position]);
        return convertView;
    }

    private static class ViewHolder {
        TextView txtName;
        TextView txtVersion;
        ImageView icon;
    }
}
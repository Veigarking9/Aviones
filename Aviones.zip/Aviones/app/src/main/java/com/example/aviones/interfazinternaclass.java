package com.example.aviones;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Calendar;

public class interfazinternaclass extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {
    int tipo;
    private int mCount = 0;
    private TextView mShowCount;



    private void escribir(String texto) {
        mShowCount.setText(texto);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        setContentView(R.layout.interfazinterna);
        mShowCount = (TextView) findViewById(R.id.editText3);
        TextView search = findViewById(R.id.textView);
        EditText from = findViewById(R.id.editText);
        EditText to = findViewById(R.id.editText2);
        TextView pasajeros = findViewById(R.id.editText3);
        RadioGroup Paradas = (RadioGroup) findViewById(R.id.radioGroup2);
        TextView vuelta = findViewById(R.id.editText5);
        TextView retur = findViewById(R.id.textView4);
        ImageView cale = findViewById(R.id.imageView2);
        vuelta.setVisibility(View.INVISIBLE);
        retur.setVisibility(View.INVISIBLE);
        cale.setVisibility(View.INVISIBLE);



        final Button sumar = findViewById(R.id.button5);
        sumar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {


                if(mCount < 19){
                    mCount++;
                    escribir(new Integer(mCount).toString());
                }
                else{
                    Toast.makeText(interfazinternaclass.this,"The maximum number of passengers is 19", Toast.LENGTH_SHORT).show();
                }

            }
        });
        final Button restar = findViewById(R.id.button4);
        restar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(mCount > 0){
                    mCount--;
                    escribir(new Integer(mCount).toString());
                }
                else{
                    Toast.makeText(interfazinternaclass.this, "The minimum number of passengers is 0", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void onFromDate(View v) {
        DialogFragment FromDatePiker = new DatePickerFragment();
        FromDatePiker.show(getSupportFragmentManager(), "selector fecha");
        tipo = 0;

    }
    public void onRoundTrip(View v){

        TextView vuelta = findViewById(R.id.editText5);
        TextView retur = findViewById(R.id.textView4);
        ImageView cale = findViewById(R.id.imageView2);
        RadioGroup Tipo = (RadioGroup) findViewById(R.id.radioGroup);



        if(Tipo.getCheckedRadioButtonId() == R.id.button) {

            vuelta.setVisibility(View.VISIBLE);
            retur.setVisibility(View.VISIBLE);
            cale.setVisibility(View.VISIBLE);

        }
    }
    public void onOneWay(View v){

    TextView vuelta = findViewById(R.id.editText5);
    TextView retur = findViewById(R.id.textView4);
    ImageView cale = findViewById(R.id.imageView2);
    RadioGroup Tipo = (RadioGroup) findViewById(R.id.radioGroup);

    if(Tipo.getCheckedRadioButtonId() == R.id.button3) {
        vuelta.setVisibility(View.INVISIBLE);
        retur.setVisibility(View.INVISIBLE);
        cale.setVisibility(View.INVISIBLE);
    }
    }
    public void onToDate(View v) {
        DialogFragment ToDatePiker = new DatePickerFragment();
        ToDatePiker.show(getSupportFragmentManager(), "selector fecha");
        tipo = 1;
    }

    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth)
    {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.YEAR, year);
        c.set(Calendar.MONTH, month);
        c.set(Calendar.DAY_OF_MONTH, dayOfMonth);
        String Date = DateFormat.getDateInstance().format(c.getTime());
        if (tipo == 0){
            TextView desde = (TextView) findViewById(R.id.editText4);
            desde.setText(Date);
        }
        if (tipo == 1){
            TextView hasta = (TextView) findViewById(R.id.editText5);
            hasta.setText(Date);
        }

    }


    public void onHistory(View view){
        TextView search = findViewById(R.id.textView);
        EditText from = findViewById(R.id.editText);
        EditText to = findViewById(R.id.editText2);
        TextView desde = findViewById(R.id.editText4);
        TextView hasta = findViewById(R.id.editText5);
        TextView pasajeros = findViewById(R.id.editText3);
        RadioGroup Tipo = (RadioGroup) findViewById(R.id.radioGroup);
        RadioGroup Paradas = (RadioGroup) findViewById(R.id.radioGroup2);
        String pard = new String();

        if(Paradas.getCheckedRadioButtonId() == R.id.button8){
            pard = "con 2 paradas o más";
        }
        if(Paradas.getCheckedRadioButtonId() == R.id.button7){
            pard = "con una parada";
        }
        if(Paradas.getCheckedRadioButtonId() == R.id.button6){
            pard = "sin paradas";
        }
        if(Tipo.getCheckedRadioButtonId() == R.id.button){
            search.setText("Reserva de vuelo, salida desde "+ from.getText()+" el dia "+desde.getText().toString()+" a "+to.getText()+", con vuelta el dia "+hasta.getText().toString()+", con "+pasajeros.getText()+" pasajeros y "+pard);

        }
        else {
            search.setText("Reserva de vuelo, salida desde "+ from.getText()+" el dia "+desde.getText().toString()+" a "+to.getText()+", con "+pasajeros.getText()+" pasajeros y "+pard);
        }


    }
    public void onSearch(View view){
        TextView desde = findViewById(R.id.editText4);
        TextView hasta = findViewById(R.id.editText5);
        EditText from = findViewById(R.id.editText);
        EditText to = findViewById(R.id.editText2);


        Intent hist = new Intent(this, listaclass.class);
        hist.putExtra("Destiny", to.getText().toString());
        hist.putExtra("Origen", from.getText().toString());
        hist.putExtra("Salida", desde.getText().toString());
        hist.putExtra("Vuelta", hasta.getText().toString());

        //Toast.makeText(MainActivity2.this, "Not able to do this action", Toast.LENGTH_SHORT).show();
        startActivity(hist);

    }
}

